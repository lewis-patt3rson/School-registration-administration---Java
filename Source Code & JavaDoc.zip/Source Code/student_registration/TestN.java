/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Student_Registration;

import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author awaism
 */
public class TestN {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        CISConnection cis = new CISConnection("cis4005");
        //cis.insertStudent("Mark", "Anderson", "0003", "F");
        cis.printAllStudents();

        ResultSet studentRS = cis.findStudentBySurname("Evans");
        try
        {
            while ((null != studentRS) && (studentRS.next()))
            {
                String id = studentRS.getString(1);
                String fname = studentRS.getString(2);
                String sname = studentRS.getString(3);
                
            }
        }
        catch (SQLException sqle)
        {
            System.out.println("Error finding student: " + sqle.toString());
        }

        //cis.insertProgramme("G500", "Computer Science");
        //cis.insertModule("OO Programming", 20, "CIS2023", "5", "1");
        cis.addModuleToProgramme(2, 1);

        cis.closeConnection();

    }
    
}
