/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package student_registration;

import java.sql.ResultSet;
import java.sql.SQLException;
import Student_Registration.CISConnection;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author bliss
 */
public class MainForm extends javax.swing.JFrame {

    /**
     * Creates new form MainForm
     * loads data into relevant areas from load methods
     */
    CISConnection cis = new CISConnection("cis4005");
    public MainForm() {
        initComponents();       
        _cmbProgrammes.removeAllItems();
        _cmbModules.removeAllItems();
        loadProgrammes();
        loadWeeks();
        loadStudents();
        refreshForm();
    }
    
    /**
     * resets form to default values
     */
    private void refreshForm()
    {
        disableEdit();
        boolean ok = false;
        enabledisableRegPanel(ok);
        disableAddMod();
    }
    
    /**
     * Checks full time attendance and flags a warning if there are 2 consecutive absences
     * @param modId module id
     */
    private void checkFullTime(int modId)
    {
       boolean warning = false;
       int consecAbsences = 0;
       ArrayList<String> warningStuIds = new ArrayList<String>();
       ArrayList<String> stuIds = cis.getStudentsFromModule(modId);
       //Checks each student against the registers for the module, those with 2 absences are added to a warning list
       for(int i =0; i <stuIds.size(); i++)
       {
            if(cis.getStudentType(Integer.parseInt(stuIds.get(i))))
            {
                if(cis.checkFullTimeAttendance(Integer.parseInt(stuIds.get(i))))
                warningStuIds.add(stuIds.get(i));
            }
       }
       
        if(warningStuIds.size()!=0)
        {
            String warningMsg = "The following fulltime students have attendance warnings:";
            String[] sdata = new String[3];
            for(int i =0; i<warningStuIds.size();i++)
            {
                //warning list is displayed
                sdata = cis.getStudentDataGivenID(Integer.parseInt(warningStuIds.get(i)));    
                warningMsg += ("\n" + sdata[2] + ": " + sdata[0] + ", " + sdata[1]);
            }
            JOptionPane.showMessageDialog(this, warningMsg);
        }     
    }
    
    /**
     * Checks part time attendance and flags a warning if there are 2 consecutive absences in a module
     * @param modId module id
     */
    private void checkPartTime(int modId)
    {
       ArrayList<String> regIds = cis.getRegistersFromModule(modId);
       ArrayList<String> stuIds = cis.getStudentsFromModule(modId);
       ArrayList<String> warningStuIds = new ArrayList<String>();
       boolean warning = false;
       int consecAbsences = 0;
       //Checks if a parttime student has attended registers for a module, adding them to a list if there are 2 consecutive absences
       for(int i =0; i < stuIds.size(); i++)
       {
           if(!cis.getStudentType(Integer.parseInt(stuIds.get(i))))
           {
               warning = false;
                for(int j =0; j < regIds.size(); j++)
                {
                    if(!cis.checkIfAttended(Integer.parseInt(stuIds.get(i)),Integer.parseInt(regIds.get(j))))
                    {
                        consecAbsences++;
                        if(consecAbsences == 2)
                            warning = true;
                    }
                    else
                        consecAbsences = 0;
                }
           if(warning)
               warningStuIds.add(stuIds.get(i));
           }
       }
       
       if(warningStuIds.size()!=0)
       {
       String warningMsg = "The following parttime students have attendance warnings for this module:";
       String[] sdata = new String[3];
       //list displayed
       for(int i =0; i<warningStuIds.size();i++)
       {
           sdata = cis.getStudentDataGivenID(Integer.parseInt(warningStuIds.get(i)));    
           warningMsg += ("\n" + sdata[2] + ": " + sdata[0] + ", " + sdata[1]);
       }
       JOptionPane.showMessageDialog(this, warningMsg);
       }
    }
    
    /**
     * disables/enables registration panel 
     * @param tf boolean which is used in the .setEnabled() for registration panel components
     */
    private void enabledisableRegPanel(boolean tf)
    {
        btnSubmitNew.setEnabled(tf);
        tblAttendanceRegister.setEnabled(tf);
        _cmbWeek.setEnabled(tf);
    }

    /**
     * loads weeks into combobox
     */
    private void loadWeeks()
    {
        _cmbWeek.removeAllItems();
        for (int i = 0; i < 52; i++) {
            _cmbWeek.addItem(""+(i+1));
        }
        _cmbViewWeeks.removeAllItems();
        for (int i = 0; i < 52; i++) {
            _cmbViewWeeks.addItem(""+(i+1));
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        _cmbProgrammes = new javax.swing.JComboBox<>();
        _cmbModules = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnTakeRegister1 = new javax.swing.JButton();
        btnTakeRegister2 = new javax.swing.JButton();
        btnTakeRegister3 = new javax.swing.JButton();
        _cmbStudents = new javax.swing.JComboBox<>();
        btnViewStu = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblAttendanceRegister = new javax.swing.JTable();
        btnSubmitNew = new javax.swing.JButton();
        _cmbWeek = new javax.swing.JComboBox<>();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtaReg = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        btnViewRegisters = new javax.swing.JButton();
        _cmbViewWeeks = new javax.swing.JComboBox<>();
        btnDeleteRegister = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        _cmbRemoveFromM = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        btnAdd = new javax.swing.JButton();
        _cmbAddToM = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btnAddMod = new javax.swing.JButton();
        _cmbAddMods = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        _cmbProgrammes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        _cmbProgrammes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _cmbProgrammesActionPerformed(evt);
            }
        });

        _cmbModules.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        _cmbModules.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _cmbModulesActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Choose Module:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Choose Programme:");

        btnTakeRegister1.setText("Take Register");
        btnTakeRegister1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTakeRegister1ActionPerformed(evt);
            }
        });

        btnTakeRegister2.setText("Add Students");
        btnTakeRegister2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTakeRegister2ActionPerformed(evt);
            }
        });

        btnTakeRegister3.setText("Add Modules");
        btnTakeRegister3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTakeRegister3ActionPerformed(evt);
            }
        });

        _cmbStudents.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        _cmbStudents.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _cmbStudentsActionPerformed(evt);
            }
        });

        btnViewStu.setText("View Details");
        btnViewStu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewStuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(49, 49, 49)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(btnTakeRegister1)
                                    .addComponent(btnTakeRegister2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnTakeRegister3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(_cmbProgrammes, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(_cmbModules, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(_cmbStudents, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnViewStu, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(_cmbProgrammes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(_cmbModules, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                .addComponent(btnTakeRegister1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnTakeRegister2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnTakeRegister3)
                .addGap(61, 61, 61)
                .addComponent(_cmbStudents, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnViewStu)
                .addGap(12, 12, 12))
        );

        tblAttendanceRegister.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student ID", "Forname", "Surname", "Present"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tblAttendanceRegister);

        jScrollPane3.setViewportView(jScrollPane2);

        btnSubmitNew.setText("Submit Register");
        btnSubmitNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitNewActionPerformed(evt);
            }
        });

        _cmbWeek.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtaReg.setEditable(false);
        txtaReg.setColumns(20);
        txtaReg.setRows(5);
        jScrollPane4.setViewportView(txtaReg);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Student/Register Details");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Student Register");

        btnViewRegisters.setText("View Register");
        btnViewRegisters.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewRegistersActionPerformed(evt);
            }
        });

        _cmbViewWeeks.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnDeleteRegister.setText("Delete Register");
        btnDeleteRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteRegisterActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Week No:");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(_cmbViewWeeks, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(btnViewRegisters, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnDeleteRegister, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(_cmbViewWeeks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnViewRegisters)
                    .addComponent(btnDeleteRegister))
                .addGap(40, 40, 40))
        );

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Edit Register");

        _cmbRemoveFromM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Students not on register:");

        btnAdd.setText("Add");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        _cmbAddToM.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Current Students:");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Add Modules:");

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Modules not in programme:");

        btnAddMod.setText("Add");
        btnAddMod.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddModActionPerformed(evt);
            }
        });

        _cmbAddMods.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Week No:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(_cmbWeek, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnSubmitNew, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 474, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(47, 47, 47)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(45, 45, 45)
                                    .addComponent(btnAdd))
                                .addComponent(_cmbAddToM, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGap(102, 102, 102)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(_cmbRemoveFromM, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jScrollPane4)))
                        .addGap(219, 219, 219))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(btnAddMod))
                            .addComponent(_cmbAddMods, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(236, 236, 236))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(209, 209, 209))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(_cmbWeek, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnSubmitNew)
                            .addComponent(jLabel11)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(_cmbAddMods, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(btnAddMod))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(_cmbAddToM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(11, 11, 11)
                                .addComponent(btnAdd))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(_cmbRemoveFromM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * When a programme is selceted, the modules for the programme fill the module combobox
     * @param evt 
     */
    private void _cmbProgrammesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__cmbProgrammesActionPerformed

        if(_cmbProgrammes.getSelectedIndex() > 0)
        {
            _cmbModules.setEnabled(true);
            String[] programme = cis.getProgrammetDataFromID(_cmbProgrammes.getSelectedItem().toString().substring(0, 4));
            //ResultSet rs = cis.returnAllModuleProgrammes();
            System.out.print(programme[0] + programme[1]);
            _cmbModules.removeAllItems();
            ResultSet rs = cis.returnAllModuleProgrammes();
            try
            {
            if (null != rs)
            {
                while(rs.next())
                {
                    if(programme[0].equalsIgnoreCase(rs.getString(3)))
                    {
                        String[] modules = cis.getModuletDataFromID(rs.getString(2));
                        _cmbModules.addItem(modules[0] + ": "+modules[1]);
                    }
                }
            }
            }
            catch (SQLException sqle)
            {
                System.out.println("Exception when loading programmes: " + sqle.toString());
            }     
    }//GEN-LAST:event__cmbProgrammesActionPerformed
    else
        {
            _cmbModules.setEnabled(false);
            _cmbModules.removeAllItems();
        }
    }
    
    /**
     * Checks if a register exists for a specific module and week, if so, displays the student info of that register in a text area
     * @param evt 
     */
    private void btnViewRegistersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewRegistersActionPerformed
       if(_cmbModules.getSelectedIndex() > -1)
        {
            int modId = Integer.parseInt(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":")));
            int week = Integer.parseInt(_cmbViewWeeks.getSelectedItem().toString());
            if(!cis.findRegisterByWeekandModule(modId, week).equalsIgnoreCase(""))
            {
            txtaReg.setText("");
            
            int regId = Integer.parseInt(cis.findRegisterByWeekandModule(modId, week));
            ArrayList<String> stuIds = cis.getStudentsFromRegister(regId);
            String[] sdata = new String[3];
            String attend = "";
            for(int i = 0; i < stuIds.size(); i++)     
            {
                sdata = cis.getStudentDataGivenID(Integer.parseInt(stuIds.get(i)));
                if(cis.checkIfAttended(Integer.parseInt(stuIds.get(i)), regId))
                    attend = "PRESENT";
                else
                    attend = "ABSENT";
                    
                txtaReg.append(sdata[2] + ": " + sdata[1] + ", " + sdata[0] + " - " + attend + "\n");
            }
            }
            else
            {
                txtaReg.setText("");
                JOptionPane.showMessageDialog(this, "There is no register for this week.");
            }
        }
    }//GEN-LAST:event_btnViewRegistersActionPerformed

    /**
     * enables reg panel and ensures a module is selected
     * @param evt 
     */
    private void btnTakeRegister1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTakeRegister1ActionPerformed
        
        if(_cmbModules.getSelectedIndex() >= 0)
        {
            loadStudentsForModule(); 
            boolean ok = true;
            enabledisableRegPanel(ok);
        }
        else
            JOptionPane.showMessageDialog(this, "You must choose a module to take a register.");
    }//GEN-LAST:event_btnTakeRegister1ActionPerformed

    /**
     * Submits a new register, after ensuring a register does not already exist.
     * checks attendance of full and part time students after submission and flags attendance errors accordingly
     * @param evt 
     */
    private void btnSubmitNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitNewActionPerformed
            
       

        if(cis.checkReg(Integer.parseInt(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":"))),Integer.parseInt(_cmbWeek.getSelectedItem().toString())))
        {
            JOptionPane.showMessageDialog(this,"A register already exists for week: " + _cmbWeek.getSelectedItem().toString() + "\nYou must delete the register for this week to make a new one.");
        }
        else if(registerValidation())
        {
            int attendees = 0;
            int modId = Integer.parseInt(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":")));
            int week = Integer.parseInt(_cmbWeek.getSelectedItem().toString());               
            try{
            for(int i=0;i<tblAttendanceRegister.getModel().getRowCount();i++)
                if (((Boolean)tblAttendanceRegister.getValueAt(i, 3)))        
                    attendees++;    
            }
             catch(NullPointerException e)
        {
            System.out.print("NullPointerException caught b");
        }
            cis.createReg(week, attendees, modId);
            int regId = Integer.parseInt(cis.findRegisterByWeekandModule(modId, week));
            for(int i=0;i<tblAttendanceRegister.getModel().getRowCount();i++)
            {      
                if (((Boolean)tblAttendanceRegister.getValueAt(i, 3)) == null || !((Boolean)tblAttendanceRegister.getValueAt(i, 3)))
                {  
                    cis.setAttendanceForRegister(regId, tblAttendanceRegister.getValueAt(i, 0).toString(), Boolean.FALSE);
                }
                else
                {
                    cis.setAttendanceForRegister(regId, tblAttendanceRegister.getValueAt(i, 0).toString(), Boolean.TRUE);
                }
            }    
            JOptionPane.showMessageDialog(this, "Register for week: " + week +" submitted.");
            cis.printAllRegisters();
            boolean check = false;
            enabledisableRegPanel(check);
            _cmbModules.setSelectedIndex(0);
            checkPartTime(modId);
            checkFullTime(modId);
            DefaultTableModel model = (DefaultTableModel) tblAttendanceRegister.getModel();   
            model.setRowCount(0);
            
        }
        
    }//GEN-LAST:event_btnSubmitNewActionPerformed

    /**
     * Deletes a register after confirming user input, if one exists for the specified week and module
     * @param evt 
     */
    private void btnDeleteRegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteRegisterActionPerformed

        if(_cmbWeek.getSelectedIndex() >= 0)
            {
            int modId = Integer.parseInt(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":")));
            int week = Integer.parseInt(_cmbViewWeeks.getSelectedItem().toString());
            if(!cis.findRegisterByWeekandModule(modId, week).equalsIgnoreCase(""))
            {
                int regId = Integer.parseInt(cis.findRegisterByWeekandModule(modId, week));
                int result = JOptionPane.showConfirmDialog(this,"Are you sure you want to delete the week " +week+ " register?\nThis cannot be undone", "Confirm Delete.", JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                if(result == JOptionPane.YES_OPTION)
                {
                    cis.removeAtt(regId);
                    cis.deleteSpecificRegister(regId);
                    txtaReg.setText("");
                    JOptionPane.showMessageDialog(this, "Register Deleted.");
                }
            }
            else
            {
                txtaReg.setText("");
                JOptionPane.showMessageDialog(this, "There is no register for this week.");
            }
            
            
        }
    }//GEN-LAST:event_btnDeleteRegisterActionPerformed

    
    private void _cmbModulesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__cmbModulesActionPerformed

    }//GEN-LAST:event__cmbModulesActionPerformed

    /**
     * Disables edit gui components
     */
    private void disableEdit()
    {
        _cmbRemoveFromM.removeAllItems();
        _cmbAddToM.removeAllItems();
        _cmbRemoveFromM.setEnabled(false);
        _cmbAddToM.setEnabled(false);
        btnAdd.setEnabled(false);
       
    }
    
    /**
     * loads students into combo box
     */
    private void loadStudents()
    {
            _cmbStudents.removeAllItems();
            String[] all = cis.getStudentIDs();
            for(int i = 0; i < all.length; i++)
            {
                String[] sdata = cis.getStudentDataGivenID(Integer.parseInt(all[i]));              
                _cmbStudents.addItem(sdata[2] + ": " + sdata[0] + ", " + sdata[1]);   
            }
        
    }
    
    /**
     * enables edit gui components
     */
    private void enableEdit()
    {
        
        
        if(_cmbModules.getSelectedIndex()>=0)
        {
             _cmbRemoveFromM.removeAllItems();
        _cmbAddToM.removeAllItems();
        _cmbRemoveFromM.setEnabled(true);
        _cmbAddToM.setEnabled(true);
        btnAdd.setEnabled(true);
        
        
            _cmbRemoveFromM.removeAllItems();
            _cmbAddToM.removeAllItems();
            int modId = Integer.parseInt(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":")));
            ArrayList<String> in = cis.getStudentsFromModule(modId);
            String[] all = cis.getStudentIDs();
            boolean found = false;
            for(int i = 0; i < all.length; i++)
            {
                for(int j = 0; j<in.size();j++)              
                    if(all[i].equalsIgnoreCase(in.get(j)))
                        found = true;
                
                String[] sdata = cis.getStudentDataGivenID(Integer.parseInt(all[i]));
                if(found)               
                    _cmbRemoveFromM.addItem(sdata[2] + ": " + sdata[0] + ", " + sdata[1]);
                else
                     _cmbAddToM.addItem(sdata[2] + ": " + sdata[0] + ", " + sdata[1]);
                found = false;
                
            }
        }
    }
    
    /**
     * calls the enable edit method
     * @param evt 
     */
    private void btnTakeRegister2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTakeRegister2ActionPerformed
        enableEdit();
    }//GEN-LAST:event_btnTakeRegister2ActionPerformed

    /**
     * disables add module gui components
     */
    private void disableAddMod()
    {
        _cmbAddMods.removeAllItems();
        btnAddMod.setEnabled(false);
        _cmbAddMods.setEnabled(false);
    }
    
    /**
     * enables add module gui components
     */
    private void enableAddMod()
    {
        btnAddMod.setEnabled(true);
        _cmbAddMods.setEnabled(true);
        _cmbAddMods.removeAllItems();
        int modId = Integer.parseInt(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":")));
        String pId = _cmbProgrammes.getSelectedItem().toString().substring(0, _cmbProgrammes.getSelectedItem().toString().indexOf("-")-1);
        ArrayList<String> in = cis.getModulesFromProgramme(Integer.parseInt(cis.getProgrammeIdFromCode(pId)));
            String[] all = cis.getModuleIDs();
            boolean found = false;
            for(int i = 0; i < all.length; i++)
            {
                for(int j = 0; j<in.size();j++)              
                    if(all[i].equalsIgnoreCase(in.get(j)))
                        found = true;
                
                String[] sdata = cis.getModuletDataFromID(all[i]);
                if(!found)               
                    _cmbAddMods.addItem(sdata[0] + ": " + sdata[1]);

                found = false;
                
            }
    }
    
    /**
     * add student to a module after user input
     * @param evt 
     */
    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
       
        if(_cmbAddToM.getSelectedIndex() >= 0)
        {
            int result = JOptionPane.showConfirmDialog(this,"Are you sure you want to add " + _cmbAddToM.getSelectedItem().toString() +"?", "Add student to module.", JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
            if(result == JOptionPane.YES_OPTION)
            {
                int modId = Integer.parseInt(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":")));
                String sId = _cmbAddToM.getSelectedItem().toString().substring(0, _cmbAddToM.getSelectedItem().toString().indexOf(":"));
                cis.addStudentToModule(modId, sId);
                JOptionPane.showMessageDialog(this, "Student added.");
                enableEdit();
            }
        }
        
    }//GEN-LAST:event_btnAddActionPerformed

    /**
     * checks if a module is selected, and if so calls method to enable add mod gui 
     * @param evt 
     */
    private void btnTakeRegister3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTakeRegister3ActionPerformed
        if(_cmbModules.getSelectedIndex() >= 0)
            enableAddMod();
    }//GEN-LAST:event_btnTakeRegister3ActionPerformed

    /**
     * Adds module to module programme in database for a specific programme
     * @param evt 
     */
    private void btnAddModActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddModActionPerformed
        if(_cmbAddMods.getSelectedIndex() >= 0)
        {
            int result = JOptionPane.showConfirmDialog(this,"Are you sure you want to add this module?", "Confirm Delete.", JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
            if(result == JOptionPane.YES_OPTION)
            {
                int modId = Integer.parseInt(_cmbAddMods.getSelectedItem().toString().substring(0, _cmbAddMods.getSelectedItem().toString().indexOf(":")));
                String pId = _cmbProgrammes.getSelectedItem().toString().substring(0, _cmbProgrammes.getSelectedItem().toString().indexOf("-")-1);
                cis.addModuleToProgramme(modId, Integer.parseInt(cis.getProgrammeIdFromCode(pId)));
                JOptionPane.showMessageDialog(this, "Module added.");
                disableAddMod();
            }
        }
    }//GEN-LAST:event_btnAddModActionPerformed
   
    private void _cmbStudentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__cmbStudentsActionPerformed

    }//GEN-LAST:event__cmbStudentsActionPerformed

    /**
     * displays information for a student in text area
     * @param evt 
     */
    private void btnViewStuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewStuActionPerformed
        
        txtaReg.setText("");
            String[] sdata = new String[3];
                int sid = Integer.parseInt(_cmbStudents.getSelectedItem().toString().substring(0, _cmbStudents.getSelectedItem().toString().indexOf(":")));
                sdata = cis.getStudentDataGivenID(sid);    
                txtaReg.append(sdata[2] + ": " + sdata[0] + ", " + sdata[1]);
                txtaReg.append("\nAttendance:\n");
                txtaReg.append(cis.returnAttendance(sid));
    }//GEN-LAST:event_btnViewStuActionPerformed
    
    /**
     * ensures a week is selected for setting new register
     * @return true if selected, false if not
     */
    private boolean registerValidation()
    {
        boolean ok = true;
        if(_cmbWeek.getSelectedIndex() < 0)
        {
            JOptionPane.showMessageDialog(this, "You must select a week for this register.");
            ok = false;
        }

        return ok;
    }
    
    /**
     * loads programmes into combo box
     */
    private void loadProgrammes()
    {
        _cmbProgrammes.removeAllItems();
        _cmbProgrammes.addItem("-");
        ResultSet rs = cis.returnAllProgrammes();
        try
        {
        if (null != rs)
        {
            while(rs.next())
            {
                _cmbProgrammes.addItem(rs.getString(2)+ " - " + rs.getString(3));
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when loading programmes: " + sqle.toString());
        }
        _cmbProgrammes.setSelectedIndex(0);
        
    }
    
    /**
     * loads students into table for a specific module
     */
    private void loadStudentsForModule(){
       
        DefaultTableModel model = (DefaultTableModel) tblAttendanceRegister.getModel();   
        model.setRowCount(0);
        ResultSet registers = cis.returnAllStudentModules();
        
        try
        {
        if (null != registers)
        {
            while(registers.next())
            {
                if(registers.getString(3).equalsIgnoreCase(_cmbModules.getSelectedItem().toString().substring(0, _cmbModules.getSelectedItem().toString().indexOf(":"))))
                {String[] student = cis.getStudentDataGivenID(Integer.parseInt(registers.getString(2)));
                    model.addRow(new Object[]{student[2], student[0], student[1]});}                                        
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all students: " + sqle.toString());
        }
}

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> _cmbAddMods;
    private javax.swing.JComboBox<String> _cmbAddToM;
    private javax.swing.JComboBox<String> _cmbModules;
    private javax.swing.JComboBox<String> _cmbProgrammes;
    private javax.swing.JComboBox<String> _cmbRemoveFromM;
    private javax.swing.JComboBox<String> _cmbStudents;
    private javax.swing.JComboBox<String> _cmbViewWeeks;
    private javax.swing.JComboBox<String> _cmbWeek;
    private javax.swing.JButton btnAdd;
    private javax.swing.JButton btnAddMod;
    private javax.swing.JButton btnDeleteRegister;
    private javax.swing.JButton btnSubmitNew;
    private javax.swing.JButton btnTakeRegister1;
    private javax.swing.JButton btnTakeRegister2;
    private javax.swing.JButton btnTakeRegister3;
    private javax.swing.JButton btnViewRegisters;
    private javax.swing.JButton btnViewStu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable tblAttendanceRegister;
    private javax.swing.JTextArea txtaReg;
    // End of variables declaration//GEN-END:variables
}
