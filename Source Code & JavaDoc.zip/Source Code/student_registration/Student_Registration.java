
package student_registration;

import Student_Registration.CISConnection;


public class Student_Registration {

    /**
     * calls the new gui form and makes it visible
     * @param args 
     */
    public static void main(String[] args) {
        
        CISConnection cis = new CISConnection("cis4005");
        MainForm form = new MainForm();
        form.setVisible(true);
        
        cis.closeConnection();
    }
}
