package Student_Registration;/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

//package uk.ac.edgehill.JDBCConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;  
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import javax.swing.JOptionPane;

/**
 *
 * @author Andersma
 */
public class CISConnection extends DBConnection {

    /**
     * Creates a new instance of the connection class, and creates a
     * connection to the named database
     * @param dbName Service name of database
     */
    public CISConnection(final String dbName)
    {
        this.connectDatabase(dbName);
    }

    /**
     * Insert a new student record into the database
     * @param forename Student forename
     * @param surname Student surname
     * @param studentNo Student number
     * @param fullPartTime Full- or part-time indicator flag (F or T)
     */
    public void insertStudent(final String forename,
            final String surname, final String studentNo, final String fullPartTime)
    {
        final String insertStmt = "INSERT INTO student (forename, surname, studentNo, fullPartTime) VALUES (?,?,?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setString(1, forename);
            pstmt.setString(2, surname);
            pstmt.setString(3, studentNo);
            pstmt.setString(4, fullPartTime);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when inserting student record: " + sqle.toString());
        }
    }
     
    /**
     * Insert a new register record into the database
     * @param weekNo week number
     * @param attendees number of attendees
     * @param module moduleid
     */
    public void createRegister(final String weekNo, final String attendees, final String module)
    {
        final String insertStmt = "INSERT INTO register (weekNo, NoOfattendees, moduleId) VALUES (?,?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setString(1, weekNo);
            pstmt.setString(2, attendees);
            pstmt.setString(3, module);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when creating register: " + sqle.toString());
        }
    }
        
    /**
     * returns student data in a string array for a specific student
     * @param id student id
     * @return student data
     */
    public String[] getStudentDataGivenID(final int id) {
        String[] data = new String[3];
        ResultSet studentRS = null;
        
        final String getQuery = "SELECT forename, surname, Id FROM student WHERE id = ?";
        try  {
            PreparedStatement pstmt = getConnection().prepareStatement(getQuery);
            pstmt.setInt(1, id);
            studentRS = pstmt.executeQuery();
        }  catch (SQLException sqle) {
            System.out.println("Exception when  getting student data: " + sqle.toString());
        }

        try {
            while ((null != studentRS) && (studentRS.next())) {
                String fname = studentRS.getString(1);
                String sname = studentRS.getString(2);
                String sid = studentRS.getString(3);
                

                data[0] = fname;
                data[1] = sname;
                data[2] = sid;
                
            }
        } catch (SQLException sqle) {
            System.out.println("Error finding student: " + sqle.toString());
        }
        return data;
    }

    /**
     * Check attendance of a specific student for a specific register
     * @param sId student id
     * @param rId register id
     * @return true if attended, false if not
     */
    public boolean checkIfAttended(final int sId, final int rId)
    {
        boolean attended = false;
        ResultSet att = null;
        final String checkStmt = "SELECT attended From studentRegister Where registerId = ? AND studentId = ?";
        try  {
            PreparedStatement pstmt = getConnection().prepareStatement(checkStmt);
            pstmt.setString(1, (rId+""));
            pstmt.setString(2, (sId+""));
            att = pstmt.executeQuery();
            try {
            while ((null != att) && (att.next())) {
                //boolean values return 1 from sql if true
                if(Integer.parseInt(att.getString(1)) == 1)
                    attended = true;
            }
        } catch (SQLException sqle) {
            System.out.println("Exception when checking individual attendance: " + sqle.toString());
        }
        }  catch (SQLException sqle) {
            System.out.println("Exception when checking individual attendance: " + sqle.toString());
        }
        return attended;
    }
    
    /**
     * Get all ids for students in the database
     * @return student ids in string array
     */
    public String[] getStudentIDs() {
        String[] ids = null;
        Vector<String> vids = new Vector<String>();

        final String retrieveQuery = "SELECT id from student";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try  {
            if (null != output)  {
                while(output.next()) {
                    String stuid = output.getString(1);

                    vids.add(stuid);
                }
            }
            int numids = vids.size();

            ids = new String[numids];

            for (int i=0; i<numids; i++) {
                ids[i] = vids.get(i);
            }
       } catch (SQLException sqle) {
            System.out.println("Exception when getting all student ids: " + sqle.toString());
       }

        return ids;
    }
    
    /**
     * returns all module ids in the database
     * @return module ids in string array
     */
    public String[] getModuleIDs() {
        String[] ids = null;
        Vector<String> vids = new Vector<String>();

        final String retrieveQuery = "SELECT id from module";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try  {
            if (null != output)  {
                while(output.next()) {
                    String mid = output.getString(1);

                    vids.add(mid);
                }
            }
            int numids = vids.size();

            ids = new String[numids];

            for (int i=0; i<numids; i++) {
                ids[i] = vids.get(i);
            }
       } catch (SQLException sqle) {
            System.out.println("Exception when getting all module ids: " + sqle.toString());
       }

        return ids;
    }

    /**
     * Find a student with a given surname
     * @param surname The surname of the student to find
     * @return ResultSet containing those students with the specified surname
     */
    public ResultSet findStudentBySurname(final String surname)
    {
        final String findStmt = "SELECT * FROM student WHERE surname = ?";
        ResultSet rs = null;
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(findStmt);
            pstmt.setString(1, surname);
            rs = pstmt.executeQuery();

        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when find student by surname: " + sqle.toString());
        }
        finally
        {
            return rs;
        }
    }
    
    /**
     * Print out all the records contained in the student table.   Prints
     * to System.out. 
     */
    public void printAllStudents()
    {
        final String retrieveQuery = "SELECT * from student";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try
        {
        if (null != output)
        {
            while(output.next())
            {
                String id = output.getString(1);
                String fname = output.getString(2);
                String sname = output.getString(3);
                String stuid = output.getString(4);
                String type = output.getString(5);
                System.out.println(id + ": " + fname + ", " + sname + " Sno: " + stuid +" Type: " + type);
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all students: " + sqle.toString());
        }

    }
    
    /**
     * prints all modules to System.out.
     */
    public void printAllStudentModules()
    {
        final String retrieveQuery = "SELECT * from studentModule";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try
        {
        if (null != output)
        {
            while(output.next())
            {
                String id = output.getString(1);
                String fname = output.getString(2);
                String sname = output.getString(3);
                System.out.println(id + ": Student: " + fname + " Module: " + sname );
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all student modules: " + sqle.toString());
        }

    }
    
    /**
     * returns all students modules in the database
     * @return result set of all student modules
     */
    public ResultSet returnAllStudentModules()
    {
        final String retrieveQuery = "SELECT * from studentModule";
        this.setQuery(retrieveQuery);
        this.runQuery();
        return this.getResultSet();
    }
    
    /**
     * returns all programmes in the database
     * @return result set of programmes
     */
    public ResultSet returnAllProgrammes()
    {
        final String retrieveQuery = "SELECT * from Programme";
        this.setQuery(retrieveQuery);
        this.runQuery();
        return this.getResultSet();
    }
    
    /**
     * returns all module programmes in the database
     * @return result set of programmes
     */
     public ResultSet returnAllModuleProgrammes()
    {
        final String retrieveQuery = "SELECT * from moduleProgramme";
        this.setQuery(retrieveQuery);
        this.runQuery();
        return this.getResultSet();
    }
    
    /**
     * finds the data for a programme from its id
     * @param code programme code to search with
     * @return programme id
     */   
    public String[] getProgrammetDataFromID(final String code)
    {
        
        String[] data = new String[3];
        ResultSet ps = null;
        
        final String getQuery = "SELECT * FROM programme WHERE programmeCode = ?";
        try  {
            PreparedStatement pstmt = getConnection().prepareStatement(getQuery);
            pstmt.setString(1, code);
            ps = pstmt.executeQuery();
        }  catch (SQLException sqle) {
            System.out.println("Exception when  getting programme data: " + sqle.toString());
        }

        try {
            while ((null != ps) && (ps.next())) {
                String fname = ps.getString(1);
                String sname = ps.getString(2);
                String sid = ps.getString(3);

                data[0] = fname;
                data[1] = sname;
                data[2] = sid;
            }
        } catch (SQLException sqle) {
            System.out.println("Error finding programme: " + sqle.toString());
        }
        return data;
    

    }
    
    /**
     * gets student ids for all students registered in a specific module
     * @param id module id
     * @return students ids
     */
    public ArrayList<String> getStudentsFromModule(final int id)
    {
        ArrayList<String> students = new ArrayList<String>();
        boolean ok= true;
        final String getStmt = "SELECT studentid FROM studentmodule WHERE moduleId = ?";
        try
        {            
            PreparedStatement pstmt  = getConnection().prepareStatement(getStmt);
            pstmt.setString(1,""+id);
            ResultSet rs = pstmt.executeQuery();
            while ((null != rs) && (rs.next()))
            {
                students.add(rs.getString(1));
            }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when getting students from module: " + sqle.toString());
        }

        return students;
        
        
        
        
    }
    
    /**
     * finds the programme id for a programme from its code (opposite of getProgrammeDataFromId)
     * @param c programme code
     * @return programme id
     */
    public String getProgrammeIdFromCode(String c)
    {
        String id = "";
        final String getQuery = "SELECT id from Programme where programmeCode = ?";
        try
        {
            PreparedStatement pstmt  = getConnection().prepareStatement(getQuery);
            pstmt.setString(1,c);
            ResultSet ms = pstmt.executeQuery();
            while ((null != ms) && (ms.next()))
            {
                id = ms.getString(1);
            }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when getting programme from code: " + sqle.toString());
        }
        return id;
    }
    
    /**
     * return all modules in database for a programme
     * @param pId programme id 
     * @return module ids
     */
    public ArrayList<String> getModulesFromProgramme(int pId)
    {
        ArrayList<String> mods = new ArrayList<String>();
        final String getQuery = "SELECT moduleId FROM moduleProgramme where programmeId = ?";
        try
        {
            PreparedStatement pstmt  = getConnection().prepareStatement(getQuery);
            pstmt.setInt(1,pId);
            ResultSet ms = pstmt.executeQuery();
            while ((null != ms) && (ms.next()))
            {
                mods.add(ms.getString(1));
            }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when getting registers from module: " + sqle.toString());
        }
        return mods;
    }
    
    /**
     * returns data on a specific module from its id
     * @param id module id
     * @return string array of module data
     */
    public String[] getModuletDataFromID(final String id)
    {
        
        String[] data = new String[3];
        ResultSet ps = null;
        
        final String getQuery = "SELECT * FROM module WHERE id = ?";
        try  {
            PreparedStatement pstmt = getConnection().prepareStatement(getQuery);
            pstmt.setString(1, id);
            ps = pstmt.executeQuery();
        }  catch (SQLException sqle) {
            System.out.println("Exception when  getting module data: " + sqle.toString());
        }

        try {
            while ((null != ps) && (ps.next())) {
                String fname = ps.getString(1);
                String sname = ps.getString(2);
                String sid = ps.getString(3);

                data[0] = fname;
                data[1] = sname;
                data[2] = sid;
            }
        } catch (SQLException sqle) {
            System.out.println("Error assigning values: " + sqle.toString());
        }
        return data;
    

    }
    
    /**
     * module programme data is output through System.Out
     */
    public void printAllModuleProgrammes()
    {
         final String retrieveQuery = "SELECT * from moduleProgramme";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try
        {
        if (null != output)
        {
            while(output.next())
            {
                String id = output.getString(1);
                String moduleId = output.getString(2);
                String programmeId = output.getString(3);
                System.out.println("ID: "+ id + " - Programme: " + programmeId + ", Module:  " + moduleId);
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all modules: " + sqle.toString());
        }
    }
    
    /**
     * module data is output through System.Out
     */
    public void printAllModules()
    {
         final String retrieveQuery = "SELECT * from Module";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try
        {
        if (null != output)
        {
            while(output.next())
            {
                String id = output.getString(1);
                String title = output.getString(2);
                String credits = output.getString(3);
                String code = output.getString(4);
                String level = output.getString(5);
                String semester = output.getString(6);
                System.out.println("ID: "+ id + " - Title: " + title + ", Code:  " + code + ", Credits: " + credits + ", Level: " + level + ", Semester: " + semester);
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all modules: " + sqle.toString());
        }
    }
   
    /**
     * programme data is output through System.Out
     */
    public void printAllProgrammes()
    {
        final String retrieveQuery = "SELECT * from Programme";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try
        {
        if (null != output)
        {
            while(output.next())
            {
                String id = output.getString(1);
                String code = output.getString(2);
                String name = output.getString(3);
                System.out.println("ID: "+ id + " - Code: " + code + ", Name:  " + name);
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all modules: " + sqle.toString());
        }
    }
    
    /**
     * register data is output through System.Out
     */
    public void printAllRegisters()
    {
        final String retrieveQuery = "SELECT * from register";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try
        {
        if (null != output)
        {
            while(output.next())
            {
                String id = output.getString(1);
                String week = output.getString(2);
                String att = output.getString(3);
                String mod = output.getString(4);
                System.out.println("ID: " + id + "Week: "+ week + " - Attendees: " + att + ", Module Id:  " + mod);
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all modules: " + sqle.toString());
        }
    }
    
    /**
     * student register data is output through System.Out
     */
    public void printAllStudentRegisters()
    {
        final String retrieveQuery = "SELECT * from studentRegister";
        this.setQuery(retrieveQuery);
        this.runQuery();
        ResultSet output = this.getResultSet();
        try
        {
        if (null != output)
        {
            while(output.next())
            {
                String id = output.getString(1);
                String stu = output.getString(2);
                String reg = output.getString(3);
                String att = output.getString(4);
                System.out.println("Id: "+ id + " - Student: " + stu + ", Register Id:  " + reg +", Attended: " + att);
            }
        }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when printing all student registers: " + sqle.toString());
        }
    }
    
    /**
     * Insert a new programme record into the database
     * @param code The programme code
     * @param name The programme name
     */
    public void insertProgramme(final String code,
            final String name)
    {
        final String insertStmt = "INSERT INTO programme (programmeCode, programmeName) VALUES (?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setString(1, code);
            pstmt.setString(2, name);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when inserting programme record: " + sqle.toString());
        }
    }
   
    /**
     * Insert a new module into the database
     * @param title The module title
     * @param credit The number of credits for the module
     * @param code The module code
     * @param level The level of the module (4,5,6 or 7)
     * @param semester The semester that the module runs in
     */
    public void insertModule(final String title, final int credit,
            final String code, final String level, final String semester)
    {
        final String insertStmt = "INSERT INTO module (moduleTitle, credits, moduleCode, level, semester) VALUES (?,?,?,?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setString(1, title);
            pstmt.setInt(2, credit);
            pstmt.setString(3, code);
            pstmt.setString(4, level);
            pstmt.setString(5, semester);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when inserting module record: " + sqle.toString());
        }
    }

    /**
     * Method to add a module to a programme
     * @param moduleId The module id of the new module
     * @param programmeId The programme id of the programme
     */
    public void addModuleToProgramme(final int moduleId, final int programmeId)
    {
        final String insertStmt = "INSERT INTO moduleprogramme (moduleId, programmeId) VALUES (?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setInt(1, moduleId);
            pstmt.setInt(2, programmeId);

            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when adding module to programme: " + sqle.toString());
        }
    }
    
    /**
     * adds student to module list
     * @param moduleId module id 
     * @param studentId student id
     */
    public void addStudentToModule(final int moduleId, final String studentId)
    {
        final String insertStmt = "INSERT INTO studentModule (studentId, moduleId) VALUES (?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setString(1, studentId);
            pstmt.setInt(2, moduleId);

            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when adding student to module: " + sqle.toString());
        }
    }

    /**
     * sets the attendance for a specific student on a specific register
     * @param registerId
     * @param studentId
     * @param attended 
     */
    public void setAttendanceForRegister(final int registerId, final String studentId, final Boolean attended)
    {
        final String insertStmt = "INSERT INTO studentRegister (registerId, studentId, attended) VALUES (?,?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setInt(1, registerId);
            pstmt.setString(2, studentId);
            pstmt.setBoolean(3, attended);

            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when setting attendance: " + sqle.toString());
        }
    }
    
    /**
     * removes records of student attending a specific register
     * @param regID 
     */
    public void removeAtt(final int regID)
    {
        final String insertStmt = "DELETE FROM studentRegister Where registerID = ?";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setInt(1, regID);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when deleting registers: " + sqle.toString());
        }
    }
    
    /**
     * returns a string separated by new lines with values (PRESENT or ABSENT) on each line for a register's attendance
     * @param sid student id
     * @return attendance string
     */
    public String returnAttendance(int sid)
    {
        String attendance = "";              
        final String checkStmt = "SELECT ATTENDED from studentRegister where studentID = ?";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(checkStmt);
            pstmt.setInt(1, sid);
            ResultSet cs = pstmt.executeQuery();
     
            while ((null != cs) && (cs.next())){
                if(cs.getString(1).equalsIgnoreCase("1"))
                 attendance += "PRESENT\n";
                else
                 attendance += "ABSENT\n";
            }
                                 
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when finding attendance: " + sqle.toString());
        }
        return attendance;
    }
    
    /**
     * checks if a student is full time or part time
     * @param sId student id
     * @return true for full time, false for part time
     */
    public boolean getStudentType(int sId)
    {
        boolean ok = false;
        final String checkStmt = "SELECT FULLPARTTIME from student where ID = ?";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(checkStmt);
            pstmt.setInt(1, sId);
            ResultSet cs = pstmt.executeQuery();
     
            while ((null != cs) && (cs.next())){
                if(cs.getString(1).equalsIgnoreCase("F"))
                    ok = true;
                else
                    ok = false;
            }
                                 
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when finding attendance: " + sqle.toString());
        }
        return ok;
    }
    
    /**
     * returns all registers for a module
     * @param moduleId module id
     * @return registers for module in array list
     */
    public ArrayList<String> getRegistersFromModule(final int moduleId)
    {
        ArrayList<String> regIds = new ArrayList<String>();
        boolean ok= true;
        final String getStmt = "SELECT id FROM register WHERE moduleId = ?";
        try
        {
            PreparedStatement pstmt  = getConnection().prepareStatement(getStmt);
            pstmt.setInt(1,moduleId);
            ResultSet rs = pstmt.executeQuery();
            while ((null != rs) && (rs.next()))
            {
                regIds.add(rs.getString(1));
            }
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when getting registers from module: " + sqle.toString());
        }

        return regIds;
    }
    
    /**
     * Checks the attendance of a full time student, firing a warning if there a 2 consecutive absences 
     * @param Sid student id
     * @return true if student has 2 consecutive absences, false if not
     */
    public boolean checkFullTimeAttendance(int Sid)
    {
        boolean ok = false;
        int consecAbsences = 0;
        final String checkStmt = "SELECT ATTENDED from studentRegister where studentID = ?";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(checkStmt);
            pstmt.setInt(1, Sid);
            ResultSet cs = pstmt.executeQuery();
     
            while ((null != cs) && (cs.next())){
                 
                 if(Integer.parseInt(cs.getString(1)) == 0)                
                     consecAbsences++;
                 else
                     consecAbsences = 0;
                 if(consecAbsences == 2)
                     ok = true;
            }
                                 
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when finding attendance: " + sqle.toString());
        }
        return ok;
    }
    
    /**
     * deletes a specific register from the database using its id
     * @param regID register id
     */
    public void deleteSpecificRegister(int regID)
    {
        final String insertStmt = "DELETE FROM Register Where id = ?";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setInt(1, regID);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when deleting registers: " + sqle.toString());
        }
    }
    
    /**
     * Removes all registers from the database
     */
    public void removeAllReg()
    {
        final String insertStmt = "DELETE FROM REGISTER";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when deleting registers: " + sqle.toString());
        }
    }
    
    /**
     * Removes all student registers from the database
     */
    public void removeAllStuReg()
    {
        final String insertStmt = "DELETE FROM studentREGISTER";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when deleting registers: " + sqle.toString());
        }
    }
    
    /**
     * inserts a new register into the database
     * @param weekNo week number
     * @param att number of attendees
     * @param moduleId module id
     */
    public void createReg(final int weekNo, final int att, final int moduleId)
    {
        final String insertStmt = "INSERT INTO Register (weekNo, NoOfAttendees, moduleId) VALUES (?,?,?)";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(insertStmt);
            pstmt.setInt(1, weekNo);
            pstmt.setInt(2, att);
            pstmt.setInt(3, moduleId);

            pstmt.executeUpdate();
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when creating register: " + sqle.toString());
        }
    }
    
    /**
     * Checks to see if a register for a specific module at a specific week exists
     * @param moduleID module id
     * @param weekNo week number
     * @return true if it exists, false if not
     */
    public boolean checkReg(final int moduleID, final int weekNo)
    {
        boolean ok = false;
        final String checkStmt = "Select * FROM Register where moduleId = ? AND weekNo = ?";
        try
        {
            PreparedStatement pstmt = getConnection().prepareStatement(checkStmt);
            pstmt.setInt(1, moduleID);
            pstmt.setInt(2, weekNo);
            ResultSet cs = pstmt.executeQuery();
            if(cs.next())
            {
                ok = true;
                System.out.println("Check: " + cs.getString(1));
            }               
            else 
                ok = false;                         
        }
        catch (SQLException sqle)
        {
            System.out.println("Exception when checking register: " + sqle.toString());
        }
        
        
        return ok;
    }
    
    /**
     * returns all students from a specific register
     * @param registerId register id
     * @return student ids for the register in an array list
     */
    public ArrayList <String> getStudentsFromRegister(final int registerId)
    {
        ArrayList<String> stuIds = new ArrayList<String>();
        ResultSet cs = null;
        final String checkStmt = "Select studentID FROM studentRegister where registerId = ?";
        try{
            PreparedStatement pstmt = getConnection().prepareStatement(checkStmt);
            pstmt.setInt(1, registerId);
            cs = pstmt.executeQuery();         
            while ((null != cs) && (cs.next())){
                 stuIds.add(cs.getString(1));
            }
        }
        catch (SQLException sqle) {
            System.out.println("Exception when getting student data: " + sqle.toString());
        }
        return (stuIds);
    }
    
    /**
     * returns a register id from sepcific module and week
     * @param moduleID module id
     * @param weekNo week number
     * @return register id
     */
    public String findRegisterByWeekandModule(final int moduleID, final int weekNo)
    {
        final String checkStmt = "Select * FROM Register where moduleId = ? AND weekNo = ?";
        String data = "";
        System.out.println("Mod: " + moduleID + ", week: " + weekNo);
        
        try  {
            PreparedStatement pstmt = getConnection().prepareStatement(checkStmt);
            pstmt.setInt(1, moduleID);
            pstmt.setInt(2, weekNo);
            ResultSet cs = pstmt.executeQuery();
             while ((null != cs) && (cs.next())) {

                data = cs.getString(1);
            }
        }  
        catch (SQLException sqle) {
            System.out.println("Exception when finding register by week and module: " + sqle.toString());
        }

        
        return data;
    }
}
